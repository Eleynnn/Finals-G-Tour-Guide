﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class Torrijos : Form
    {
        public Torrijos()
        {
            InitializeComponent();
        }

        private void Torrijos_Load(object sender, EventArgs e)
        {
            pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_121655.png");
            pbPlacesInTorri.Show();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbTorrijos.SelectedItem==null)
            {
                MessageBox.Show("Please Select Location!","Message Info!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            if (cbTorrijos.Text == "Poctoy White Beach")
            {
                pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\tr1.png");
                pbTorrijos.Show();
            }
            if (cbTorrijos.Text == "Hinulugan Falls")
            {
                pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\tr2.png");
                pbTorrijos.Show();
            }
            if (cbTorrijos.Text == "Talisay Cave")
            {
                pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\tr5.png");
                pbTorrijos.Show();
            }
            if (cbTorrijos.Text == "Pulang Lupa Shrine")
            {
                pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\tr3.png");
                pbTorrijos.Show();
            }
            if (cbTorrijos.Text == "Poctoy Underwater Museum")
            {
                pbPlacesInTorri.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\tr4.png");
                pbTorrijos.Show();
            }

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            //goto to viewplace form
            ViewPlaces viewPlace = new ViewPlaces();
            viewPlace.Show();
            this.Close();
        }
    }
}
