﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class Buenavista : Form
    {
        public Buenavista()
        {
            InitializeComponent();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbBuenavista.SelectedItem == null)
            {
                MessageBox.Show("Please Select Location!", "Message Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cbBuenavista.Text == "Malbog Sulfur Spring")
            {
                pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Bv1.png");
                pbBuenavistaPlaces.Show();
            }
            if (cbBuenavista.Text == "Kawilihin Park")
            {
                pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Bv2.png");
                pbBuenavistaPlaces.Show();
            }
            if (cbBuenavista.Text == "Bellarosa Island Resort")
            {
                pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Bv3.png");
                pbBuenavistaPlaces.Show();
            }
            if (cbBuenavista.Text == "Buenavista SeaView Park")
            {
                pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Bv4.png");
                pbBuenavistaPlaces.Show();
            }
            if (cbBuenavista.Text == "Mount Malindig")
            {
                pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Bv5.png");
                pbBuenavistaPlaces.Show();
            }
        }

        private void Buenavista_Load(object sender, EventArgs e)
        {
            //picture of buenavista
            pbBuenavistaPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_102626.png");
            pbBuenavistaPlaces.Show();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewPlaces viewPlace=new ViewPlaces();
            viewPlace.Show();
            this.Close();
        }
    }
}
