using System.Web;

namespace G_Tour_Guide
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            btnView.Hide(); //kapag nag run ang form na ito, naka hide and viewing button

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //kapag empty yung textbox kahit isa jan, di maga show yung viewing button
            if (string.IsNullOrEmpty(tbUsername.Text) || string.IsNullOrEmpty(tbPassword.Text))
            {
                btnView.Hide(); //viewing button is hide
                MessageBox.Show("Inputs should not be empty!","Message Info!",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else
            {
                btnView.Show(); // viewing button in shown
                MessageBox.Show("Successfully Log In!", "Message Info!", MessageBoxButtons.OK,MessageBoxIcon.None); //show message box kapag may laman ang username at password

            }
        }

        private void btnView_Click(object sender, EventArgs e) // viewing button if click will go to ViewPlaces Form
        {
            ViewPlaces viewplaces = new ViewPlaces();
            viewplaces.Show();
            this.Hide(); //this Form1 should be hidden.
        }
    }
}