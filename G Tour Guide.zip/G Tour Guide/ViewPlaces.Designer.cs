﻿namespace G_Tour_Guide
{
    partial class ViewPlaces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewPlaces));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnBuenavista = new System.Windows.Forms.Button();
            this.btnGasan = new System.Windows.Forms.Button();
            this.btnTorrijos = new System.Windows.Forms.Button();
            this.btnBoac = new System.Windows.Forms.Button();
            this.btnSantaCruz = new System.Windows.Forms.Button();
            this.btnMogpog = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(356, 372);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel5.Controls.Add(this.btnBuenavista);
            this.panel5.Controls.Add(this.btnGasan);
            this.panel5.Controls.Add(this.btnTorrijos);
            this.panel5.Controls.Add(this.btnBoac);
            this.panel5.Controls.Add(this.btnSantaCruz);
            this.panel5.Controls.Add(this.btnMogpog);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(23, 14);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(309, 345);
            this.panel5.TabIndex = 1;
            // 
            // btnBuenavista
            // 
            this.btnBuenavista.BackColor = System.Drawing.Color.SteelBlue;
            this.btnBuenavista.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBuenavista.ForeColor = System.Drawing.Color.White;
            this.btnBuenavista.Location = new System.Drawing.Point(103, 268);
            this.btnBuenavista.Margin = new System.Windows.Forms.Padding(2);
            this.btnBuenavista.Name = "btnBuenavista";
            this.btnBuenavista.Size = new System.Drawing.Size(102, 37);
            this.btnBuenavista.TabIndex = 7;
            this.btnBuenavista.Text = "Buenavista";
            this.btnBuenavista.UseVisualStyleBackColor = false;
            this.btnBuenavista.Click += new System.EventHandler(this.btnBuenavista_Click);
            // 
            // btnGasan
            // 
            this.btnGasan.BackColor = System.Drawing.Color.SteelBlue;
            this.btnGasan.Font = new System.Drawing.Font("Broadway", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnGasan.ForeColor = System.Drawing.Color.White;
            this.btnGasan.Location = new System.Drawing.Point(103, 228);
            this.btnGasan.Margin = new System.Windows.Forms.Padding(2);
            this.btnGasan.Name = "btnGasan";
            this.btnGasan.Size = new System.Drawing.Size(102, 37);
            this.btnGasan.TabIndex = 6;
            this.btnGasan.Text = "Gasan";
            this.btnGasan.UseVisualStyleBackColor = false;
            this.btnGasan.Click += new System.EventHandler(this.btnGasan_Click);
            // 
            // btnTorrijos
            // 
            this.btnTorrijos.BackColor = System.Drawing.Color.SteelBlue;
            this.btnTorrijos.Font = new System.Drawing.Font("Broadway", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTorrijos.ForeColor = System.Drawing.Color.White;
            this.btnTorrijos.Location = new System.Drawing.Point(103, 188);
            this.btnTorrijos.Margin = new System.Windows.Forms.Padding(2);
            this.btnTorrijos.Name = "btnTorrijos";
            this.btnTorrijos.Size = new System.Drawing.Size(102, 37);
            this.btnTorrijos.TabIndex = 5;
            this.btnTorrijos.Text = "Torrijos";
            this.btnTorrijos.UseVisualStyleBackColor = false;
            this.btnTorrijos.Click += new System.EventHandler(this.btnTorrijos_Click);
            // 
            // btnBoac
            // 
            this.btnBoac.BackColor = System.Drawing.Color.SteelBlue;
            this.btnBoac.Font = new System.Drawing.Font("Broadway", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnBoac.ForeColor = System.Drawing.Color.White;
            this.btnBoac.Location = new System.Drawing.Point(103, 148);
            this.btnBoac.Margin = new System.Windows.Forms.Padding(2);
            this.btnBoac.Name = "btnBoac";
            this.btnBoac.Size = new System.Drawing.Size(102, 37);
            this.btnBoac.TabIndex = 4;
            this.btnBoac.Text = "Boac";
            this.btnBoac.UseVisualStyleBackColor = false;
            this.btnBoac.Click += new System.EventHandler(this.btnBoac_Click);
            // 
            // btnSantaCruz
            // 
            this.btnSantaCruz.BackColor = System.Drawing.Color.SteelBlue;
            this.btnSantaCruz.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSantaCruz.ForeColor = System.Drawing.Color.White;
            this.btnSantaCruz.Location = new System.Drawing.Point(103, 107);
            this.btnSantaCruz.Margin = new System.Windows.Forms.Padding(2);
            this.btnSantaCruz.Name = "btnSantaCruz";
            this.btnSantaCruz.Size = new System.Drawing.Size(102, 37);
            this.btnSantaCruz.TabIndex = 3;
            this.btnSantaCruz.Text = "Santa Cruz";
            this.btnSantaCruz.UseVisualStyleBackColor = false;
            this.btnSantaCruz.Click += new System.EventHandler(this.btnSantaCruz_Click);
            // 
            // btnMogpog
            // 
            this.btnMogpog.BackColor = System.Drawing.Color.SteelBlue;
            this.btnMogpog.Font = new System.Drawing.Font("Broadway", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnMogpog.ForeColor = System.Drawing.Color.White;
            this.btnMogpog.Location = new System.Drawing.Point(103, 67);
            this.btnMogpog.Margin = new System.Windows.Forms.Padding(2);
            this.btnMogpog.Name = "btnMogpog";
            this.btnMogpog.Size = new System.Drawing.Size(102, 37);
            this.btnMogpog.TabIndex = 2;
            this.btnMogpog.Text = "Mogpog";
            this.btnMogpog.UseVisualStyleBackColor = false;
            this.btnMogpog.Click += new System.EventHandler(this.btnMogpog_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.SteelBlue;
            this.panel9.Controls.Add(this.btnExit);
            this.panel9.Location = new System.Drawing.Point(0, 318);
            this.panel9.Margin = new System.Windows.Forms.Padding(2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(309, 27);
            this.panel9.TabIndex = 1;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnExit.Location = new System.Drawing.Point(0, 1);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(54, 27);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SteelBlue;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(309, 57);
            this.panel6.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Broadway", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(48, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "G - Tour Guide";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(922, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(48, 372);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(356, 327);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(566, 45);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(356, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(566, 45);
            this.panel4.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(356, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(566, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // ViewPlaces
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(970, 372);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ViewPlaces";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewPlaces";
            this.Load += new System.EventHandler(this.ViewPlaces_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel9;
        private Panel panel6;
        private Label label1;
        private Button btnBuenavista;
        private Button btnGasan;
        private Button btnTorrijos;
        private Button btnBoac;
        private Button btnSantaCruz;
        private Button btnMogpog;
        private Button btnExit;
        private PictureBox pictureBox1;
    }
}