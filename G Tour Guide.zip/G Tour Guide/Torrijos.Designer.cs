﻿namespace G_Tour_Guide
{
    partial class Torrijos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pbTorrijos = new System.Windows.Forms.PictureBox();
            this.btnOkay = new System.Windows.Forms.Button();
            this.cbTorrijos = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TorrijosMainPanel = new System.Windows.Forms.Panel();
            this.pbPlacesInTorri = new System.Windows.Forms.PictureBox();
            this.pbTorrijosPlaces = new System.Windows.Forms.PictureBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTorrijos)).BeginInit();
            this.panel6.SuspendLayout();
            this.TorrijosMainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlacesInTorri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTorrijosPlaces)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(576, 564);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel5.Controls.Add(this.btnReturn);
            this.panel5.Controls.Add(this.pbTorrijos);
            this.panel5.Controls.Add(this.btnOkay);
            this.panel5.Controls.Add(this.cbTorrijos);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(71, 29);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(441, 514);
            this.panel5.TabIndex = 2;
            // 
            // pbTorrijos
            // 
            this.pbTorrijos.Image = global::G_Tour_Guide.Properties.Resources.torrijos;
            this.pbTorrijos.Location = new System.Drawing.Point(32, 122);
            this.pbTorrijos.Name = "pbTorrijos";
            this.pbTorrijos.Size = new System.Drawing.Size(377, 183);
            this.pbTorrijos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTorrijos.TabIndex = 4;
            this.pbTorrijos.TabStop = false;
            // 
            // btnOkay
            // 
            this.btnOkay.BackColor = System.Drawing.Color.SteelBlue;
            this.btnOkay.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnOkay.ForeColor = System.Drawing.Color.White;
            this.btnOkay.Location = new System.Drawing.Point(144, 372);
            this.btnOkay.Name = "btnOkay";
            this.btnOkay.Size = new System.Drawing.Size(142, 59);
            this.btnOkay.TabIndex = 3;
            this.btnOkay.Text = "Okay";
            this.btnOkay.UseVisualStyleBackColor = false;
            this.btnOkay.Click += new System.EventHandler(this.btnOkay_Click);
            // 
            // cbTorrijos
            // 
            this.cbTorrijos.FormattingEnabled = true;
            this.cbTorrijos.Items.AddRange(new object[] {
            "Poctoy White Beach",
            "Hinulugan Falls",
            "Talisay Cave",
            "Pulang Lupa Shrine",
            "Poctoy Underwater Museum"});
            this.cbTorrijos.Location = new System.Drawing.Point(123, 321);
            this.cbTorrijos.Name = "cbTorrijos";
            this.cbTorrijos.Size = new System.Drawing.Size(182, 33);
            this.cbTorrijos.TabIndex = 2;
            this.cbTorrijos.Text = "Select location";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.SteelBlue;
            this.panel9.Location = new System.Drawing.Point(1, 469);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(441, 45);
            this.panel9.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SteelBlue;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(441, 95);
            this.panel6.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Broadway", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(56, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "G - Tour Guide";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(576, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1131, 75);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(576, 489);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1131, 75);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(1639, 75);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(68, 414);
            this.panel4.TabIndex = 4;
            // 
            // TorrijosMainPanel
            // 
            this.TorrijosMainPanel.Controls.Add(this.pbPlacesInTorri);
            this.TorrijosMainPanel.Controls.Add(this.pbTorrijosPlaces);
            this.TorrijosMainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TorrijosMainPanel.Location = new System.Drawing.Point(576, 75);
            this.TorrijosMainPanel.Name = "TorrijosMainPanel";
            this.TorrijosMainPanel.Size = new System.Drawing.Size(1063, 414);
            this.TorrijosMainPanel.TabIndex = 5;
            // 
            // pbPlacesInTorri
            // 
            this.pbPlacesInTorri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbPlacesInTorri.Location = new System.Drawing.Point(0, 0);
            this.pbPlacesInTorri.Name = "pbPlacesInTorri";
            this.pbPlacesInTorri.Size = new System.Drawing.Size(1063, 414);
            this.pbPlacesInTorri.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlacesInTorri.TabIndex = 1;
            this.pbPlacesInTorri.TabStop = false;
            // 
            // pbTorrijosPlaces
            // 
            this.pbTorrijosPlaces.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbTorrijosPlaces.Location = new System.Drawing.Point(0, 0);
            this.pbTorrijosPlaces.Name = "pbTorrijosPlaces";
            this.pbTorrijosPlaces.Size = new System.Drawing.Size(1063, 414);
            this.pbTorrijosPlaces.TabIndex = 0;
            this.pbTorrijosPlaces.TabStop = false;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(13, 429);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(83, 34);
            this.btnReturn.TabIndex = 5;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // Torrijos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1707, 564);
            this.Controls.Add(this.TorrijosMainPanel);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1707, 564);
            this.MinimumSize = new System.Drawing.Size(1707, 564);
            this.Name = "Torrijos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Torrijos";
            this.Load += new System.EventHandler(this.Torrijos_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbTorrijos)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.TorrijosMainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbPlacesInTorri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTorrijosPlaces)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel5;
        private Panel panel9;
        private Panel panel6;
        private Label label1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel TorrijosMainPanel;
        private PictureBox pbTorrijos;
        private Button btnOkay;
        private ComboBox cbTorrijos;
        private PictureBox pbTorrijosPlaces;
        private PictureBox pbPlacesInTorri;
        private Button btnReturn;
    }
}