﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class ViewPlaces : Form
    {
        public ViewPlaces()
        {
            InitializeComponent();
        }

        private void ViewPlaces_Load(object sender, EventArgs e)
        {

        }

        private void btnMogpog_Click(object sender, EventArgs e)
        {
            Mogpog mogpog = new Mogpog();
            mogpog.Show();
            this.Hide();
        }

        private void btnSantaCruz_Click(object sender, EventArgs e)
        {
            SantaCruz santacruz = new SantaCruz();
            santacruz.Show();
            this.Hide();
        }

        private void btnBoac_Click(object sender, EventArgs e)
        {
            Boac boac = new Boac();
            boac.Show();
            this.Hide();
        }

        private void btnTorrijos_Click(object sender, EventArgs e)
        {
            Torrijos torrijos = new Torrijos();
            torrijos.Show();
            this.Hide();
        }

        private void btnGasan_Click(object sender, EventArgs e)
        {
            Gasan gasan = new Gasan();
            gasan.Show();
            this.Hide();
        }

        private void btnBuenavista_Click(object sender, EventArgs e)
        {
            Buenavista buenavista = new Buenavista();
            buenavista.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
