﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class Mogpog : Form
    {
        public Mogpog()
        {
            InitializeComponent();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewPlaces viewPlaces = new ViewPlaces();
            viewPlaces.Show();
            this.Close();
        }

        private void Mogpog_Load(object sender, EventArgs e)
        {
            //picture of mogpog
            pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_102716.png");
            pbMogpogPlaces.Show();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbMogpog.SelectedItem == null)
            {
                MessageBox.Show("Please Select Location!", "Message Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cbMogpog.Text == "Luzon Datum of 1911")
            {
                pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\m1.png");
                pbMogpogPlaces.Show();
            }
            if (cbMogpog.Text == "Paadjao Falls")
            {
                pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\m2.png");
                pbMogpogPlaces.Show();
            }
            if (cbMogpog.Text == "Natangco Island")
            {
                pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\m3.png");
                pbMogpogPlaces.Show();
            }
            if (cbMogpog.Text == "Balanacan View Deck")
            {
                pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\m4.png");
                pbMogpogPlaces.Show();
            }
            if (cbMogpog.Text == "Tarug Rock Formation")
            {
                pbMogpogPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\m5.png");
                pbMogpogPlaces.Show();
            }
        }
    }
}
