﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class SantaCruz : Form
    {
        public SantaCruz()
        {
            InitializeComponent();
        }

        private void SantaCruz_Load(object sender, EventArgs e)
        {
            //picture of santa cruz
            pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_102541.png");
            pbSantaCruzPlaces.Show();

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewPlaces viewPlaces = new ViewPlaces();
            viewPlaces.Show();
            this.Close();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbSantaCruz.SelectedItem == null)
            {
                MessageBox.Show("Please Select Location!", "Message Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cbSantaCruz.Text == "Maniwaya Island")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC3.png");
                pbSantaCruzPlaces.Show();
            }
            if (cbSantaCruz.Text == "Panuluyan")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC2.png");
                pbSantaCruzPlaces.Show();
            }
            if (cbSantaCruz.Text == "Kawa-kawa")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC1.png");
                pbSantaCruzPlaces.Show();
            }
            if (cbSantaCruz.Text == "Bathala Cave")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC5.png");
                pbSantaCruzPlaces.Show();
            }
            if (cbSantaCruz.Text == "Mongpong Island")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC4.png");
                pbSantaCruzPlaces.Show();
            }
            if (cbSantaCruz.Text == "Bagumbayan Cave")
            {
                pbSantaCruzPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\SC6.png");
                pbSantaCruzPlaces.Show();
            }
        }
    }
}
