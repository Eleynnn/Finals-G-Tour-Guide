﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class Gasan : Form
    {
        public Gasan()
        {
            InitializeComponent();
        }

        private void Gasan_Load(object sender, EventArgs e)
        {
            //picture of gasan
            pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_121608.png");
            pbGasanPlaces.Show();

        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbGasan.SelectedItem == null)
            {
                MessageBox.Show("Please Select Location!", "Message Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cbGasan.Text == "Gasan Butterfly Garden")
            {
                pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\g1.png");
                pbGasanPlaces.Show();
            }
            if (cbGasan.Text == "St. Joseph Parish")
            {
                pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\g2.png");
                pbGasanPlaces.Show();
            }
            if (cbGasan.Text == "Gasan Seaview Park")
            {
                pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\g3.png");
                pbGasanPlaces.Show();
            }
            if (cbGasan.Text == "Mang illeol")
            {
                pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\g4.png");
                pbGasanPlaces.Show();
            }
            if (cbGasan.Text == "Tres Reyes Island")
            {
                pbGasanPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\g5.png");
                pbGasanPlaces.Show();
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewPlaces viewPlaces = new ViewPlaces();
            viewPlaces.Show();
            this.Close();
        }
    }
}
