﻿namespace G_Tour_Guide
{
    partial class SantaCruz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SantaCruz));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnOkay = new System.Windows.Forms.Button();
            this.cbSantaCruz = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pbPlacesInTorri = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pbSantaCruzPlaces = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlacesInTorri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSantaCruzPlaces)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 338);
            this.panel1.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.btnReturn);
            this.panel5.Controls.Add(this.btnOkay);
            this.panel5.Controls.Add(this.cbSantaCruz);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(50, 17);
            this.panel5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(309, 308);
            this.panel5.TabIndex = 2;
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(9, 257);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(58, 20);
            this.btnReturn.TabIndex = 5;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnOkay
            // 
            this.btnOkay.BackColor = System.Drawing.Color.SteelBlue;
            this.btnOkay.Font = new System.Drawing.Font("Broadway", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnOkay.ForeColor = System.Drawing.Color.White;
            this.btnOkay.Location = new System.Drawing.Point(101, 223);
            this.btnOkay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOkay.Name = "btnOkay";
            this.btnOkay.Size = new System.Drawing.Size(99, 35);
            this.btnOkay.TabIndex = 3;
            this.btnOkay.Text = "Okay";
            this.btnOkay.UseVisualStyleBackColor = false;
            this.btnOkay.Click += new System.EventHandler(this.btnOkay_Click);
            // 
            // cbSantaCruz
            // 
            this.cbSantaCruz.FormattingEnabled = true;
            this.cbSantaCruz.Items.AddRange(new object[] {
            "Maniwaya Island",
            "Panuluyan",
            "Kawa-kawa",
            "Bathala Cave",
            "Mongpong Island",
            "Bagumbayan Cave"});
            this.cbSantaCruz.Location = new System.Drawing.Point(86, 193);
            this.cbSantaCruz.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cbSantaCruz.Name = "cbSantaCruz";
            this.cbSantaCruz.Size = new System.Drawing.Size(129, 23);
            this.cbSantaCruz.TabIndex = 2;
            this.cbSantaCruz.Text = "Select location";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.SteelBlue;
            this.panel9.Location = new System.Drawing.Point(1, 281);
            this.panel9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(309, 27);
            this.panel9.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SteelBlue;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(309, 57);
            this.panel6.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Broadway", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(39, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "G - Tour Guide";
            // 
            // pbPlacesInTorri
            // 
            this.pbPlacesInTorri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbPlacesInTorri.Location = new System.Drawing.Point(403, 45);
            this.pbPlacesInTorri.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbPlacesInTorri.Name = "pbPlacesInTorri";
            this.pbPlacesInTorri.Size = new System.Drawing.Size(519, 248);
            this.pbPlacesInTorri.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlacesInTorri.TabIndex = 5;
            this.pbPlacesInTorri.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(922, 45);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(48, 248);
            this.panel4.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(403, 293);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(567, 45);
            this.panel3.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(403, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(567, 45);
            this.panel2.TabIndex = 6;
            // 
            // pbSantaCruzPlaces
            // 
            this.pbSantaCruzPlaces.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbSantaCruzPlaces.Location = new System.Drawing.Point(403, 45);
            this.pbSantaCruzPlaces.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pbSantaCruzPlaces.Name = "pbSantaCruzPlaces";
            this.pbSantaCruzPlaces.Size = new System.Drawing.Size(519, 248);
            this.pbSantaCruzPlaces.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSantaCruzPlaces.TabIndex = 9;
            this.pbSantaCruzPlaces.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(23, 78);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(264, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // SantaCruz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(970, 338);
            this.Controls.Add(this.pbSantaCruzPlaces);
            this.Controls.Add(this.pbPlacesInTorri);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximumSize = new System.Drawing.Size(1195, 338);
            this.MinimumSize = new System.Drawing.Size(955, 338);
            this.Name = "SantaCruz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SantaCruz";
            this.Load += new System.EventHandler(this.SantaCruz_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlacesInTorri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSantaCruzPlaces)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel5;
        private Button btnReturn;
        private Button btnOkay;
        private ComboBox cbSantaCruz;
        private Panel panel9;
        private Panel panel6;
        private Label label1;
        private PictureBox pbPlacesInTorri;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private PictureBox pbSantaCruzPlaces;
        private PictureBox pictureBox1;
    }
}