﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace G_Tour_Guide
{
    public partial class Boac : Form
    {
        public Boac()
        {
            InitializeComponent();
        }

        private void Boac_Load(object sender, EventArgs e)
        {
            //picture of boac
            pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\Screenshots\Screenshot_20221223_102453.png");
            pbBoacPlaces.Show();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            if (cbBoac.SelectedItem == null)
            {
                MessageBox.Show("Please Select Location!", "Message Info!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cbBoac.Text == "Boac Cathedral")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b1.png");
                pbBoacPlaces.Show();
            }
            if (cbBoac.Text == "Mt. Baliis Sea of Clouds")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b2.png");
                pbBoacPlaces.Show();
            }
            if (cbBoac.Text == "Duyay Cave")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b3.png");
                pbBoacPlaces.Show();
            }
            if (cbBoac.Text == "Kabugsukan Falls")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b4.png");
                pbBoacPlaces.Show();
            }
            if (cbBoac.Text == "A&A Beach Resort")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b5.png");
                pbBoacPlaces.Show();
            }
            if (cbBoac.Text == "Marinduque National Museum")
            {
                pbBoacPlaces.Image = Image.FromFile(@"C:\Users\Ellaine Joyce\OneDrive\Pictures\b6.png");
                pbBoacPlaces.Show();
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            ViewPlaces viewPlaces = new ViewPlaces();
            viewPlaces.Show();
            this.Close();
        }
    }
}
